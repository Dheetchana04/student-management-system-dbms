import mysql.connector
from flask_login import UserMixin
from app import bcrypt
from config import Config
import mysql.connector
from flask_login import UserMixin
from config import Config

class User(UserMixin):
    def __init__(self, user_id, username, password):
        self.id = user_id
        self.username = username
        self.password = password

    @staticmethod
    def find_by_username(username):
        mysql_conn1 = mysql.connector.connect(
            user=Config.MYSQL_USER,
            password=Config.MYSQL_PASSWORD,
            host=Config.MYSQL_HOST,
            database=Config.MYSQL_DATABASE
        )
        cursor = mysql_conn1.cursor()
        query = "SELECT * FROM staff WHERE regsiter_number = %s"
        cursor.execute(query, (username,))
        user_data = cursor.fetchone()
        cursor.close()
        mysql_conn1.close()

        if user_data:
            user = User(user_data[0], user_data[1], user_data[2])
            return user
        return None

    @staticmethod
    def find_by_id(user_id):
        mysql_conn1 = mysql.connector.connect(
            user=Config.MYSQL_USER,
            password=Config.MYSQL_PASSWORD,
            host=Config.MYSQL_HOST,
            database=Config.MYSQL_DATABASE
        )
        cursor = mysql_conn1.cursor()
        query = "SELECT * FROM staff WHERE id = %s"
        cursor.execute(query, (user_id,))
        user_data = cursor.fetchone()
        cursor.close()
        mysql_conn1.close()

        if user_data:
            user = User(user_data[0], user_data[1], user_data[2])
            return user
        return None

    @staticmethod
    def authenticate(username, password):
        user = User.find_by_username(username)
        if user and user.password == password:
            return user
        return None

class Student:
    @staticmethod
    def get_all_students():
        mysql_conn2 = mysql.connector.connect(
            user=Config.MYSQL_USER_LOG,
            password=Config.MYSQL_PASSWORD_LOG,
            host=Config.MYSQL_HOST_LOG,
            database=Config.MYSQL_DATABASE_LOG
        )
        cursor = mysql_conn2.cursor(dictionary=True)
        query = "SELECT * FROM students"
        cursor.execute(query)
        student_data = cursor.fetchall()
        cursor.close()
        mysql_conn2.close()
        return student_data

    @staticmethod
    def find_by_register_no(register_no):
        mysql_conn2 = mysql.connector.connect(
            user=Config.MYSQL_USER_LOG,
            password=Config.MYSQL_PASSWORD_LOG,
            host=Config.MYSQL_HOST_LOG,
            database=Config.MYSQL_DATABASE_LOG
        )
        cursor = mysql_conn2.cursor(dictionary=True)
        query = "SELECT * FROM students WHERE register_no = %s"
        cursor.execute(query, (register_no,))
        student_data = cursor.fetchone()
        cursor.close()
        mysql_conn2.close()
        return student_data
