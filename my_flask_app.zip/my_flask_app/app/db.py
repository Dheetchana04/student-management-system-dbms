import mysql.connector

# Function to establish MySQL connection for staff_details database
def get_mysql_conn1():
    return mysql.connector.connect(
        user='root',
        password='Dheetchu04@.',
        host='localhost',
        database='staff_details'
    )

# Function to establish MySQL connection for student_log database
def get_mysql_conn2():
    return mysql.connector.connect(
        user='root',
        password='Dheetchu04@.',
        host='localhost',
        database='student_log'
)
