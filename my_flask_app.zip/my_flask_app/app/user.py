import mysql.connector
from flask_login import UserMixin
from app import bcrypt

class User(UserMixin):
    def __init__(self, user_id, username, password_hash):
        self.id = user_id
        self.username = username
        self.password_hash = password_hash

    @staticmethod
    def find_by_username(username):
        # Example query to find user by username
        mysql_conn1 = mysql.connector.connect(
            user='root',
            password='Dheetchu04@.',
            host='localhost',
            database='staff_details'
        )
        cursor = mysql_conn1.cursor()
        query = "SELECT * FROM staff WHERE register_number = %s"
        cursor.execute(query, (username,))
        user_data = cursor.fetchone()
        cursor.close()

        if user_data:
            user = User(user_data[0], user_data[1], user_data[2])  # Assuming user_id, username, password_hash
            return user
        return None

    @staticmethod
    def find_by_id(user_id):
        # Example query to find user by user_id
        mysql_conn1 = mysql.connector.connect(
            user='root',
            password='Dheetchu04@.',
            host='localhost',
            database='staff_details'
        )
        cursor = mysql_conn1.cursor()
        query = "SELECT * FROM staff WHERE id = %s"
        cursor.execute(query, (user_id,))
        user_data = cursor.fetchone()
        cursor.close()

        if user_data:
            # Replace with actual column indices based on your database schema
            user = User(user_data[0], user_data[1], user_data[2])  # Assuming user_id, username, password_hash
            return user
        return None

    @staticmethod
    def authenticate(username, password):
        user = User.find_by_username(username)
        if user and bcrypt.check_password_hash(user.password_hash, password):
            return user
        return None
