from flask import Blueprint, render_template, redirect, url_for, flash, request, session, abort
from flask_login import login_user, current_user, logout_user, login_required
from app.models import User, Student  # Adjust import paths as per your project structure
import mysql.connector
from config import Config

main = Blueprint('main', __name__)

@main.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main.nextpage'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user = User.authenticate(username, password)
        
        if user:
            login_user(user)
            return redirect(url_for('main.nextpage'))
        else:
            flash('Login Unsuccessful. Please check username and password', 'danger')
    
    return render_template('login.html')

@main.route('/nextpage', methods=['GET', 'POST'])
@login_required
def nextpage():
    if request.method == 'POST':
        roll_no = request.form.get('roll_no')
        student = Student.find_by_register_no(roll_no)
        if not student:
            flash('Invalid roll number. Please try again.', 'danger')
            return redirect(url_for('main.nextpage'))
        return redirect(url_for('main.details', roll_no=roll_no))
    
    return render_template('nextpage.html')

@main.route('/details/<roll_no>')
@login_required
def details(roll_no):
    student = Student.find_by_register_no(roll_no)
    if not student:
        abort(404)
    
    return render_template('details.html', student=student)

@main.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('main.login'))
