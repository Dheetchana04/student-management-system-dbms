from flask import Flask

app = Flask(__name__)

class Config:
    # Configuration for Database 1 (staff_details)
    MYSQL_USER = 'root'
    MYSQL_PASSWORD = 'Dheetchu04@.'
    MYSQL_HOST = 'localhost'
    MYSQL_DATABASE = 'staff_details'

    # Configuration for Database 2 (student_log)
    MYSQL_USER_LOG = 'root'
    MYSQL_PASSWORD_LOG = 'Dheetchu04@.'
    MYSQL_HOST_LOG = 'localhost'
    MYSQL_DATABASE_LOG = 'student_log'

    SECRET_KEY = '244562f84405dcb4b313885e06aa6530e850c81c945d2ff9'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
